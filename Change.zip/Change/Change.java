/*
* @author Evan O'Neill
* 24/03/23
* Change.java
*/

public class Change{
	private double amount;
	private int twoEuro, oneEuro, fiftyCent, twentyCent, tenCent, fiveCent, twoCent, oneCent, coins;

	public Change(){
		amount = 0;
		twoEuro = 0;
		oneEuro = 0;
		fiftyCent = 0;
		twentyCent = 0;
		tenCent = 0;
		fiveCent = 0;
		twoCent = 0;
		oneCent = 0;
		coins = 0;

	}


	public void Change(double amount){

		this.amount = amount;


		System.out.println("information entered = correct ");

	}

	public void setAmount(){
		this.amount = amount;


	}


	public void computeCoins(){
		coins = twoEuro + oneEuro + fiftyCent + twentyCent + tenCent + fiveCent + twoCent + oneCent;
		}

	public int getTwoEuro(){
			return twoEuro;
		}

	public int getOneEuro(){
			return oneEuro;
		}

	public int getFiftyCent(){
			return fiftyCent;
		}

	public int getTwentyCent(){
			return twentyCent;
		}

	public int getTenCent(){
			return tenCent;
		}

	public int getFiveCent(){
			return fiveCent;
		}

	public int getTwoCent(){
			return twoCent;
		}

	public int getOneCent(){
			return oneCent;
		}

	public double getAmount(){
		return amount;
		}


}