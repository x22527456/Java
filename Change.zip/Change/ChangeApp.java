/*
* @author Evan O'Neill
* 24/03/23
* ChangeApp.java
*/
import javax.swing.JOptionPane;
public class ChangeApp{
	public static void main(String args[]){
		double amount;
		int twoEuro, oneEuro, fiftyCent, twentyCent, tenCent, fiveCent, twoCent, oneCent, coins;

		Change person;

		amount = Integer.parseInt(JOptionPane.showInputDialog(null, "amount: "));

		person = new Change();

		JOptionPane.showMessageDialog(null, "your change: " + person.getAmount() );


		}


}
