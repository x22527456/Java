/*
*@author EvanO'Neill
*31/03/23
*Counting.java
*/

public class Counting{
	private String Input;
	private int numbers;
	private int vowels;
	private int spaces;

	public Counting(){
		Input = "";
		numbers = 0;
		vowels = 0;
		spaces = 0;

	}
	public void setInput(String Input){
		this.Input = Input;

		}

		public void compute(){
			for (int i = 0; i < Input.length(); i++) {
			            // check if int[i] is vowel
			            if (Input.charAt(i) == 'a' || Input.charAt(i) == 'e'
			                || Input.charAt(i) == 'i'
			                || Input.charAt(i) == 'o'
			                || Input.charAt(i) == 'u') {

                vowels++;
		}
				if(Input.charAt(i) == '1'
					|| Input.charAt(i) == '2'
			        || Input.charAt(i) == '3'
			        || Input.charAt(i) == '4'
			        || Input.charAt(i) == '5'
					|| Input.charAt(i) == '6'
			        || Input.charAt(i) == '7'
			        || Input.charAt(i) == '8'
			        || Input.charAt(i) == '9'
					|| Input.charAt(i) == '0'




			                ) {

                numbers++;
		}
		if(Input.charAt(i) == ' '
							)
						{
						spaces++;
			}
}
}
	public int getNumbers(){
		return numbers;
		}
	public int getVowels(){
		return vowels;
	}
	public int getSpaces(){
		return spaces;
		}
}