/*
* @author Evan O'Neill
* 10/03/23
* StarSignApp.java
*/
import javax.swing.JOptionPane;
public class StarSignApp{
	public static void main(String args[]){
		// declare
		int  date;
		String month, sign;

		StarSign five = new StarSign();

		month = JOptionPane.showInputDialog(null, "enter Month: ");

		date = Integer.parseInt(JOptionPane.showInputDialog(null, "enter Date: "));
		five.setMonth(month);
		five.setDate(date);
		five.compute();

		JOptionPane.showMessageDialog(null, "Your Star Sign is" + five.getSign());




	}


}