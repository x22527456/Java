/*
* @author Evan O'Neill
* 10/03/23
* StarSign.java
*/
public class StarSign{
	// declare
	private int  date;
	private String month,sign;

	//constructor
	public StarSign(){
		month = "";
		date = 0;
		sign = "";

	}
	//set all strings and ints that require input from user
	public void setMonth(String month){
		this.month = month;
	}
	public void setDate(int date){
			this.date = date;
	}

	// if else statements using compute method
	public void compute(){
		if(month.equalsIgnoreCase("january")){
			if (date >= 1 && date <= 19){
				sign = "Capricorn";
				} else if (date >=20 && date <= 31){
					sign = "Aquarius";
				}
				}else if(month.equalsIgnoreCase("Febuary")){
					if (date >= 1 && date <= 18){
						sign = "Aquarius";
						} else if (date >= 19 && date <= 28){
							sign = "Pisces";
				}
				}else if(month.equalsIgnoreCase("March")){
					if (date >= 1 && date <= 20){
						sign = "Pisces";
						} else if (date >=21 && date <= 31){
							sign = "Aries";
				}
				}else if(month.equalsIgnoreCase("April")){
					if (date >= 1 && date <= 19){
						sign = "Aries";
						} else if (date >=20 && date <= 31){
							sign = "Taurius";
				}
				}if(month.equalsIgnoreCase("May")){
					if (date >= 1 && date <= 20){
						sign = "Taurius";
						} else if (date >=21 && date <= 30){
							sign = "Gemini";
						}
				}if(month.equalsIgnoreCase("June")){
					if (date >= 1 && date <= 20){
						sign = "Gemini";
						} else if (date >=21 && date <= 31){
							sign = "Cancer";
						}
				}else if(month.equalsIgnoreCase("july")){
					if (date >= 1 && date <= 22){
						sign = "Cancer";
						} else if (date >=23 && date <= 31){
							sign = "Leo";
						}
				}else if(month.equalsIgnoreCase("August")){
					if (date >= 1 && date <= 22){
						sign = "Leo";
						} else if (date >=23 && date <= 31){
							sign = "Virgo";
						}
				}else if(month.equalsIgnoreCase("September")){
					if (date >= 1 && date <= 19){
						sign = "Virgo";
						} else if (date >=20 && date <= 30){
							sign = "Libra";
						}
				}else if(month.equalsIgnoreCase("october")){
					if (date >= 1 && date <= 22){
						sign = "libra";
						} else if (date >=23 && date <= 31){
							sign = "Scorpio";
						}
				}else if(month.equalsIgnoreCase("November")){
					if (date >= 1 && date <= 21){
						sign = "Scorpio";
						} else if (date >=22 && date <= 30){
							sign = "Sagittaurius";
						}
				}else if(month.equalsIgnoreCase("December")){
					if (date >= 1 && date <= 21){
						sign = "Sagittaurius";
						} else if (date >=22 && date <= 31){
							sign = "Capricorn";
						}
				}
			}
				public String getSign(){
							return sign ;
						}

	}






