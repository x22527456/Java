/*
*@author Evan O'Neill
*31/03/23
*CountingApp.java
*/
import javax.swing.JOptionPane;
public class CountingApp{
	public static void main(String args[]){
		//declare variable
		String Input;

		//create object
		Counting myInput = new Counting();

		//input
		Input = JOptionPane.showInputDialog(null,"Please enter a sentence here:");
		myInput.setInput(Input);

		//proccess
		myInput.compute();

		//output
		JOptionPane.showMessageDialog(null,"there is "+ myInput.getVowels() + " of vowels");
		JOptionPane.showMessageDialog(null,"there is "+ myInput.getSpaces() + " of spaces");
		JOptionPane.showMessageDialog(null,"there is "+ myInput.getNumbers() + " of numbers");




		}

}