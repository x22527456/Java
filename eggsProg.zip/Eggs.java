/*
* @author Evan O'Neill
* 17/02/2023
* Eggs.Java
*/
import java.util.Scanner;
public class Eggs{

	public static void main(String args[]){
		int amEggs, result, boxEggs;


	Scanner keyboard = new Scanner(System.in);
	Collect CalcIt = new Collect();

	System.out.println("enter the amount of eggs collected: " );
	amEggs = keyboard.nextInt();
	CalcIt.setAmEggs(amEggs);

	CalcIt.divid();

	System.out.println("the amount of boxes needed are: " + CalcIt.getResult());

}

}