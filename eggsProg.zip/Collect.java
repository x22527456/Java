/*
* @author Evan O'Neill
* 17/02/2023
* Collect.java
*/

public class Collect{
	private int amEggs, boxEggs, result;

	public Collect(){
		amEggs = 0;
		boxEggs = 0;
		result = 0;


	}

	public void setAmEggs(int amEggs){
		this.amEggs = amEggs;

		}


	public void setBoxEggs(int boxEggs){
		this.boxEggs = boxEggs;
		}


	public void setResult(int result){
		this.result = result;

		}

		//maths

	public void divid(){
		result = amEggs / 12;

		}




}